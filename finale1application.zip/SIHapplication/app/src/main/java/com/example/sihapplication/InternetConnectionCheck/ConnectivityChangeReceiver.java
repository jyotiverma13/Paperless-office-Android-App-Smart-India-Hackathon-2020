package com.example.sihapplication.InternetConnectionCheck;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Abhishek on 21-09-2017.
 */

public class ConnectivityChangeReceiver extends BroadcastReceiver


    {
        public static final String NETWORK_AVAILABLE_ACTION = "com.onstechnography.jhalawarapp.jhalawar.NetworkAvailable";
        public static final String IS_NETWORK_AVAILABLE = "isNetworkAvailable";

        @Override
        public void onReceive(Context context, Intent intent) {
        Intent networkStateIntent = new Intent(NETWORK_AVAILABLE_ACTION);
        networkStateIntent.putExtra(IS_NETWORK_AVAILABLE,  isConnectedToInternet(context));
        LocalBroadcastManager.getInstance(context).sendBroadcast(networkStateIntent);
    }

    private boolean isConnectedToInternet(Context context) {
        try {
            if (context != null) {
                ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
                return networkInfo != null && networkInfo.isAvailable() && networkInfo.isConnected();
            }
            return false;
        } catch (Exception e) {
            Log.e(ConnectivityChangeReceiver.class.getName(), e.getMessage());
            return false;
        }
    }
}