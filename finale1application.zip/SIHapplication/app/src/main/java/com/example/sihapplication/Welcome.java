package com.example.sihapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.example.sihapplication.InternetConnectionCheck.CheckNetworkConnection;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Welcome extends Activity {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);
       if(CheckNetworkConnection.isConnectionAvailable(this)){
           Thread t=new Thread(){
               @Override
                public void run() {
                  try{
                        sleep(3000);
                    }catch (Exception e)
                    {

                    }
                    finally {
                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                        if(user!=null){
                            startActivity(new Intent(getApplicationContext(), Home.class));
                        }
                        else{
                         Intent i=new Intent(getBaseContext(), LoginActivity.class);
                           startActivity(i);
                       }

                  }

              }
           };

        t.start();
        }
       else{
           Toast.makeText(getApplicationContext(),"No Internet Connection",Toast.LENGTH_SHORT).show();
       }
    }
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
