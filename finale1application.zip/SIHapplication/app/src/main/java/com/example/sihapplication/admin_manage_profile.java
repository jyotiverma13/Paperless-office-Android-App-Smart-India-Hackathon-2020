package com.example.sihapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import de.hdodenhof.circleimageview.CircleImageView;

public class admin_manage_profile extends AppCompatActivity {
    CircleImageView dp_reset;
    TextView name_reset;
    TextView email;
    TextView design_name;
    TextView phone_reset;
    TextView cat_reset;
    TextView cat_level;
    TextView state_reset;
    TextView district_reset;
    TextView dpt;
    Button pswdlink;
    FirebaseAuth mAuth;
    String uid;
    FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_manage_profile);
        db=FirebaseFirestore.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        uid=user.getUid();
        dpt=findViewById(R.id.department);
        email=findViewById((R.id.adminemail));
        dp_reset = (CircleImageView) findViewById(R.id.admindpreset);

        name_reset=(TextView)findViewById(R.id.adminnamereset);

        design_name=(TextView)findViewById(R.id.designationnamereset);

        phone_reset=(TextView)findViewById(R.id.adminphonereset);

        cat_reset=(TextView)findViewById(R.id.admincatgryreset);

        cat_level=(TextView)findViewById(R.id.admincatlevelreset);

        state_reset=(TextView)findViewById(R.id.adminstatereset);

        district_reset=(TextView)findViewById(R.id.admindistrictreset);

        pswdlink=(Button)findViewById(R.id.adpswdlink);
        pswdlink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText resetmail=new EditText((view.getContext()));
                AlertDialog.Builder pswdreset_dialog= new AlertDialog.Builder(view.getContext());
                pswdreset_dialog.setTitle("Reset Password");
                pswdreset_dialog.setMessage("Enter Registered Email To Recieve Password Reset Link");
                pswdreset_dialog.setView(resetmail);
                pswdreset_dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //extract the email and send link
                        String mail = resetmail.getText().toString().trim();
                        mAuth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(getApplicationContext(),"Link Sent",Toast.LENGTH_LONG).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(),"Error! Link Not Sent"+e.getMessage(),Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                });
                pswdreset_dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //close dialoge
                    }
                });
                pswdreset_dialog.create().show();

            }
        });
        readdata();
           }
    public void readdata(){
        db.collection("Admin").whereEqualTo("uid",uid)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("DATA", document.getId() + " => " + document.getData());
                                String NAME=document.get("fullname").toString();
                                String DEPARTMENT=document.get("department").toString();
                                String DESIGNATION=document.get("designation").toString();
                                String PHONE=document.get("phone").toString();
                                String CATEGORY=document.get("category").toString();
                                String LEVEL=document.get("level").toString();
                                String STATE=document.get("state").toString();
                                String DISTRICT=document.get("district").toString();
                                String EMAIL=document.get("email").toString();

                                name_reset.setText(NAME);
                                email.setText(EMAIL);
                                design_name.setText(DESIGNATION);
                                dpt.setText(DEPARTMENT);
                                phone_reset.setText(PHONE);
                                cat_reset.setText(CATEGORY);
                                cat_level.setText(LEVEL);
                                state_reset.setText(STATE);
                                district_reset.setText(DISTRICT);

                                String url=document.get("dpurl").toString();
                                Glide
                                        .with(getApplicationContext())
                                        .load(url)
                                        .centerCrop()
                                        .into(dp_reset);


                            }
                        } else {
                            Log.w("Data1", "Error getting documents.", task.getException());
                        }
                    }
                });

    }

}