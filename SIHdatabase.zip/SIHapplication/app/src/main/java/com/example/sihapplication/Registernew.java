package com.example.sihapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.sihapplication.ui.UserProfile;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.Arrays;

public class Registernew extends AppCompatActivity {
    EditText email;
    EditText password;
    EditText cnfpass;
    EditText full_name;
    private FirebaseAuth mAuth;
    ProgressBar progressBar;
    String email1,password1,cnfpass1,fullname;
// ...
// Initialize Firebase Auth

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registernew);
        email=(EditText)findViewById(R.id.email);
        password=(EditText)findViewById(R.id.password);
        cnfpass=(EditText)findViewById(R.id.confirm_password);
        full_name=(EditText)findViewById(R.id.fullname);
        progressBar=findViewById(R.id.progressBar);
        mAuth = FirebaseAuth.getInstance();

    }

    public void opencontinue(View view){
      startposting();
    }

    public void startposting()
    {
         email1=email.getText().toString().trim();
        password1=password.getText().toString().trim();
         cnfpass1=cnfpass.getText().toString().trim();
         fullname=full_name.getText().toString().trim();
        if (TextUtils.isEmpty(email1)){
            email.setError("Invalid Email");
            return;
        }
        if (TextUtils.isEmpty(password1)){
            password.setError("Password is Required");
            return;
        }
        if(password1.length()<8){
            password.setError("Password must be equals to 8 char. or more");
        }
        if(password1.equals(cnfpass1)){
            //cnfpass.setError("Password Same");
        }else {
            cnfpass.setError("Password must be same");
        }

        if(password1.equals(cnfpass1)){
            mAuth.createUserWithEmailAndPassword(email1, password1)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            progressBar.setVisibility(View.VISIBLE);
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                sendUserdata();
                                FirebaseUser user = mAuth.getCurrentUser();
                                Toast.makeText(getApplicationContext(),"User Register Success",Toast.LENGTH_LONG).show();

                            } else {
                                // If sign in fails, display a message to the user.
                                Toast.makeText(getApplicationContext(),"User Register not Suceed",Toast.LENGTH_LONG).show();

                            }

                            // ...
                        }
                    });

        }

    }
    private void sendUserdata(){
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference myRef = firebaseDatabase.getReference(mAuth.getUid());
        UserProfile userProfile = new UserProfile(fullname,email1,password1);
        myRef.setValue(userProfile);
    }

}