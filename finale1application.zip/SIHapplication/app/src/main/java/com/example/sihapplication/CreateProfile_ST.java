package com.example.sihapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class CreateProfile_ST extends AppCompatActivity {
    String[] st_state={"Rajasthan","MP","UP"};
    String[] st_district_raj={"Jhalawar","Kota"};
    String[] st_district_mp={"Bhopal","Indore","Ujjain"};
    String[] st_district_up={"Kanpur","Lucknow","Agra"};
    String[] st_category={"General","OBC","SC/ST"};
    Spinner Category;
    Spinner st_states;
    Spinner st_district;
    String [] selected_state={"Select State To View Districts"};
    CircleImageView dp;
    EditText fullname;
    EditText phone;
    String userid;
    Uri dpuri=null;
    Button post;
    String selection;
    String category;
    String ditrict;
    String email;
    ProgressBar progressBar;
    private StorageReference mStorageRef;
    CollectionReference db;
    String selecteduser;
    private static final String fileName="usertype";
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.st_createprofile);
        progressBar=findViewById(R.id.progressBar3);
        fullname= findViewById(R.id.fullname);
        phone=findViewById(R.id.userphone);
        db= FirebaseFirestore.getInstance().collection("Students");
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        mStorageRef = FirebaseStorage.getInstance().getReference();
        userid=getIntent().getExtras().getString("userid");
        email=user.getEmail();
        post=findViewById(R.id.st_post);
        st_district=(Spinner)findViewById(R.id.district_st);
        st_district.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                ditrict=adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            if(TextUtils.isEmpty(phone.getText().toString().trim())&&TextUtils.isEmpty(fullname.getText().toString().trim())&&dpuri==null){
                Toast.makeText(getApplicationContext(),"All Fields Are Mandatory",Toast.LENGTH_SHORT).show();
                return;
                }
                else {
                    posting();
                }
            }
        });
        dp=(CircleImageView)findViewById(R.id.studentdpreset);
        dp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent galleryIntent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(galleryIntent,0);
            }
        });

        Category=(Spinner)findViewById(R.id.category_st);
        ArrayAdapter<String> arrayAdapter0=new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,st_category);
        Category.setAdapter(arrayAdapter0);
        Category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                category=adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        st_states=(Spinner)findViewById(R.id.state_st);
        ArrayAdapter<String> arrayAdapter1=new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,st_state);
        st_states.setAdapter(arrayAdapter1);
        st_states.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                 selection=adapterView.getItemAtPosition(i).toString();
                if(selection=="Rajasthan"){
                    Toast.makeText(getApplicationContext(),selection,Toast.LENGTH_SHORT).show();
                    selected_state=st_district_raj;
                    dist(st_district_raj);
                }
                else if(selection=="MP")
                {
                    selected_state=st_district_mp;
                        dist(st_district_mp);
                }
                else {
                    selected_state=st_district_up;
                    dist(st_district_up);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



    }
    public void dist(String [] dst)
    {
        ArrayAdapter<String> arrayAdapter2=new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,dst);
        st_district.setAdapter(arrayAdapter2);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    if(requestCode==0){
        if(resultCode==RESULT_OK){
            dpuri= data.getData();
            dp.setImageURI(dpuri);
        }
    }
    }
    public void posting(){
        progressBar.setVisibility(View.VISIBLE);
        final String FullName_st=fullname.getText().toString().trim();
        final String PhoneNo_st=phone.getText().toString().trim();
        final String state=selection;
        final String category1=category;
        final String district1=ditrict;

       final StorageReference filepath = mStorageRef.child("student_dp").child(dpuri.getLastPathSegment());
       UploadTask uploadTask=filepath.putFile(dpuri);

       Task<Uri> uriTask=uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
           @Override
           public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
               return filepath.getDownloadUrl();
           }
       }).addOnSuccessListener(new OnSuccessListener<Uri>() {
           @Override
           public void onSuccess(Uri uri) {
               Uri download_uri=uri;
               Map<String,Object> student_data=new HashMap();
               student_data.put("name",FullName_st);
               student_data.put("phone",PhoneNo_st);
               student_data.put("category",category1);
               student_data.put("state",state);
               student_data.put("district",district1);
               student_data.put("dpurl",download_uri.toString());
               student_data.put("uid",userid);
               student_data.put("email",email);
               student_data.put("usertype","Students");

               db.document(userid).set(student_data).addOnCompleteListener(new OnCompleteListener<Void>() {
                   @Override
                   public void onComplete(@NonNull Task<Void> task) {
                       progressBar.setVisibility(View.GONE);
                       saveuser();
                       finish();
                       startActivity(new Intent(getApplicationContext(), Home.class));
                   }
               });

               Toast.makeText(getApplicationContext(),download_uri.toString(),Toast.LENGTH_SHORT).show();
           }
       });

    }
    private void saveuser(){
        selecteduser="Students";
        SharedPreferences sharedPreferences=getSharedPreferences(fileName, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString("usertype",selecteduser);
        editor.commit();
        Toast.makeText(getApplicationContext(),"User Set to Students",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        deleteAccount();
        finish();
    }

    private void deleteAccount() {
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        final FirebaseUser currentUser = firebaseAuth.getCurrentUser();

        currentUser.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                  //  Log.d(TAG,"OK! Works fine!");
                    Toast.makeText(getApplicationContext(),"k",Toast.LENGTH_SHORT).show();

                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(),"error",Toast.LENGTH_SHORT).show();
                //Log.e(TAG,"Ocurrio un error durante la eliminación del usuario", e);
            }
        });
    }
}
