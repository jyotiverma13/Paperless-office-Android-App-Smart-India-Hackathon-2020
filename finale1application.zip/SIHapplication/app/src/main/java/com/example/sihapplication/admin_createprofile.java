package com.example.sihapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageException;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class admin_createprofile extends AppCompatActivity {
    Spinner dept;
    String[] select_dept = {"Scholarship","AICTE", "TEQUIP", "Sports", "Others"};
    Spinner adm_commity_level;
    String[] commity_level_string = {"National", "State", "District"};
    Spinner adm_commity_category;
    String[] category = {"General", "OBC", "SC/ST"};
    Spinner adm_state;
    String[] state = {"Rajasthan", "MP", "UP"};
    Spinner adm_district;

    String[] selected_state = {"Select State To View Districts"};
    String[] district_raj = {"Jhalawar", "Kota"};
    String[] district_mp = {"Bhopal", "Indore", "Ujjain"};
    String[] district_up = {"Kanpur", "Lucknow", "Agra"};
    Button submit_adm;
    CircleImageView adm_dp;
    EditText commityName, sch_designation, sch_phone;
    String userid;
    Uri uri_adm_dp=null;
    String department;
    String cat;
    String levelnational;
    String levelstate="null";
    String leveldistrict="null";
    private StorageReference mStorageRef;
    CollectionReference db;
    String selecteduser;
    private static final String fileName="usertype";
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_createprofile);
        mStorageRef = FirebaseStorage.getInstance().getReference();
        db= FirebaseFirestore.getInstance().collection("Admin");
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        email=user.getEmail();
        adm_dp = findViewById(R.id.adm_dp);
        sch_designation = findViewById(R.id.adm_sch_designation);
        sch_phone = findViewById(R.id.adm_sch_phone);
        userid = getIntent().getExtras().getString("userid");
        submit_adm = findViewById(R.id.submit_adm);
        submit_adm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(uri_adm_dp==null&&TextUtils.isEmpty(sch_phone.getText().toString().trim())&&TextUtils.isEmpty(commityName.getText().toString().trim())
                &&TextUtils.isEmpty(sch_designation.getText().toString().trim())){
                    Toast.makeText(getApplicationContext(),"All Fields Are Mandatory",Toast.LENGTH_SHORT).show();
                }
                else {posting();}
            }
        });
        adm_district = (Spinner) findViewById(R.id.adm_dist);
        adm_district.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                leveldistrict=adapterView.getItemAtPosition(i).toString();
                Toast.makeText(getApplicationContext(),leveldistrict,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        adm_dp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(galleryIntent, 0);
            }
        });
        commityName = findViewById(R.id.adm_fullname);
        dept = (Spinner) findViewById(R.id.select_dept);
        ArrayAdapter<String> arrayAdapter0 = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, select_dept);
        dept.setAdapter(arrayAdapter0);
        dept.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                department=adapterView.getItemAtPosition(i).toString();
                Toast.makeText(getApplicationContext(),department,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        adm_commity_level = (Spinner) findViewById(R.id.adm_commity_level);
        ArrayAdapter<String> arrayAdapter1 = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, commity_level_string);
        adm_commity_level.setAdapter(arrayAdapter1);
        adm_commity_level.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String level = adapterView.getItemAtPosition(i).toString();
                levelnational=adapterView.getItemAtPosition(i).toString();
                Toast.makeText(getApplicationContext(),levelnational,Toast.LENGTH_SHORT).show();
                if (level == "National") {

                    if (adm_district.getVisibility() == View.VISIBLE) {
                        levelstate="null";
                        leveldistrict="null";
                        adm_district.setVisibility(View.GONE);
                        adm_state.setVisibility(View.GONE);
                    } else if (adm_state.getVisibility() == View.VISIBLE) {
                        levelstate="null";
                        adm_state.setVisibility(View.GONE);
                    }


                } else if (level == "State") {

                    if (adm_state.getVisibility() != View.VISIBLE) {
                        adm_state.setVisibility(View.VISIBLE);

                    }
                    if (adm_district.getVisibility() == View.GONE) {

                    } else {
                        adm_district.setVisibility(View.GONE);
                        leveldistrict="null";
                    }
                } else if (level == "District") {
                    if (adm_state.getVisibility() == View.VISIBLE) {
                        adm_district.setVisibility(View.VISIBLE);
                    } else {
                        adm_state.setVisibility(View.VISIBLE);
                        adm_district.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        adm_commity_category = findViewById(R.id.adm_commity_category);
        ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, category);
        adm_commity_category.setAdapter(arrayAdapter2);
        adm_commity_category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                cat=adapterView.getItemAtPosition(i).toString();
                Toast.makeText(getApplicationContext(),cat,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        adm_state = findViewById(R.id.adm_state);
        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, state);
        adm_state.setAdapter(arrayAdapter3);
        adm_state.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String selection = adapterView.getItemAtPosition(i).toString();
                levelstate=adapterView.getItemAtPosition(i).toString();
                Toast.makeText(getApplicationContext(),levelstate,Toast.LENGTH_SHORT).show();
                if (selection == "Rajasthan") {
                    Toast.makeText(getApplicationContext(), selection, Toast.LENGTH_SHORT).show();
                    selected_state = district_raj;
                    dist(district_raj);
                } else if (selection == "MP") {
                    selected_state = district_mp;
                    dist(district_mp);
                } else {
                    selected_state = district_up;
                    dist(district_up);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //adm_district=findViewById(R.id.adm_dist);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                uri_adm_dp = data.getData();
                adm_dp.setImageURI(uri_adm_dp);
            }
        }
    }

    public void dist(String[] dst) {

        ArrayAdapter<String> arrayAdapter4 = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, dst);
        adm_district.setAdapter(arrayAdapter4);

    }

    void posting() {
        submit_adm.setEnabled(false);
        final String adm_full_name = commityName.getText().toString().trim();
        final String dsg = sch_designation.getText().toString().trim();
        final String Phoneadm = sch_phone.getText().toString().trim();
        final String department1=department;
        final String cat1=cat;
        final String level1n=levelnational;
        final String level2s=levelstate;
        final String level3d=leveldistrict;
        if (TextUtils.isEmpty(adm_full_name)){
            commityName.setError("Enter Your Name !");
        }


        final StorageReference filePath=mStorageRef.child("admin_dp").child(uri_adm_dp.getLastPathSegment());
        UploadTask uploadTask=filePath.putFile(uri_adm_dp);
        Task<Uri> uriTask=uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                return filePath.getDownloadUrl();
            }
        }).addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Uri downloadUri=uri;
                Map<String ,Object>admin_data=new HashMap();
                admin_data.put("fullname",adm_full_name);
                admin_data.put("designation",dsg);
                admin_data.put("phone",Phoneadm);
                admin_data.put("department",department1);
                admin_data.put("category",cat1);
                admin_data.put("level",level1n);
                admin_data.put("state",level2s);
                admin_data.put("district",level3d);
                admin_data.put("uid",userid);
                admin_data.put("email",email);
                admin_data.put("usertype","Admin");
                admin_data.put("esign","null");
                admin_data.put("dpurl",downloadUri.toString());
                admin_data.put("token","null");
                db.document(userid).set(admin_data).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        saveuser();
                        finish();
                        startActivity(new Intent(getApplicationContext(), Home.class));
                    }
                });
                Toast.makeText(getApplicationContext(),downloadUri.toString(),Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                submit_adm.setEnabled(true);
            }
        });

    }
    private void saveuser(){
        selecteduser="Admin";
        SharedPreferences sharedPreferences=getSharedPreferences(fileName, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString("usertype",selecteduser);
        editor.commit();
        Toast.makeText(getApplicationContext(),"User Set to Admin",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        deleteAccount();
        finish();
    }



    private void deleteAccount() {
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        final FirebaseUser currentUser = firebaseAuth.getCurrentUser();

        currentUser.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    // Log.d(TAG,"OK! Works fine!");
                    Toast.makeText(getApplicationContext(),"k",Toast.LENGTH_SHORT).show();

                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                //Log.e(TAG,"Ocurrio un error durante la eliminación del usuario", e);
            }
        });
    }
}