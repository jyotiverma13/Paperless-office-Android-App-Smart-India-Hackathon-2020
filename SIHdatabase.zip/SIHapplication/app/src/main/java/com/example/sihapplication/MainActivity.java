package com.example.sihapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    private static final String[] departments = new String[]{
            "Student","Scholarship","Tequip","Sports","WHO","Others"
    };
    private EditText editTextUsername;
    private EditText editTextPassword;
    TextView forgot_password;
    Button buttonLogin;
    FirebaseAuth mAuth;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       /* AutoCompleteTextView editText=findViewById(R.id.actv1);
        ArrayAdapter<String>adapter=new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,departments);
        editText.setAdapter(adapter);*/
        editTextUsername=findViewById(R.id.eTemail);
        editTextPassword=findViewById(R.id.etPassword);
        buttonLogin=findViewById(R.id.button1);
        progressBar=findViewById((R.id.login_progressBar));
        mAuth=FirebaseAuth.getInstance();
        editTextUsername.addTextChangedListener(loginTextWatcher);
        editTextPassword.addTextChangedListener(loginTextWatcher);
        forgot_password=(TextView)findViewById(R.id.forgetPassword);
        forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText resetmail=new EditText((view.getContext()));
                AlertDialog.Builder pswdreset_dialog= new AlertDialog.Builder(view.getContext());
                pswdreset_dialog.setTitle("Reset Password");
                pswdreset_dialog.setMessage("Enter Registered Email To Recieve Password Reset Link");
                pswdreset_dialog.setView(resetmail);
                pswdreset_dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //extract the email and send link
                        String mail = resetmail.getText().toString().trim();
                        mAuth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(getApplicationContext(),"Link Sent",Toast.LENGTH_LONG).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(),"Error! Link Not Sent"+e.getMessage(),Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                });
                pswdreset_dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //close dialoge
                    }
                });
                pswdreset_dialog.create().show();
                //            Intent intent=new Intent(MainActivity.this,forgot_password.class);
//            startActivity(intent);
            }
        });
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernameInput = editTextUsername.getText().toString().trim();
                String passwordInput = editTextPassword.getText().toString().trim();
                if (TextUtils.isEmpty(usernameInput)){
                    editTextUsername.setError("Invalid Email");
                    return;
                }
                if (TextUtils.isEmpty(passwordInput)){
                    editTextPassword.setError("Password is Required");
                    return;
                }
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                if(passwordInput.length()<8){
                    editTextPassword.setError("Password must be equals to 8 char. or more");
                }
                progressBar.setVisibility(View.VISIBLE);
                FirebaseAuth.getInstance().signInWithEmailAndPassword(usernameInput,passwordInput)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                    startActivity(new Intent(getApplicationContext(),navactivity.class));
                                    // ...
                                }

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(),"User login failed",Toast.LENGTH_LONG).show();
                    }
                });
                // log exception to server
                //
                //register user login
//            mAuth.signInWithEmailAndPassword(usernameInput,passwordInput)
//                    .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
//                        @Override
//                        public void onComplete(@NonNull Task<AuthResult> task) {
//                            if (task.isSuccessful()) {
//                                //startActivity(new Intent(getApplicationContext(),navactivity.class));
//                                FirebaseUser user = mAuth.getCurrentUser();
//
//                            } else {
//                                Toast.makeText(getApplicationContext(),"User Register not Suceed",Toast.LENGTH_LONG).show();
//
//                            }
//
//                            // ...
//                        }
//                    });
            }
        });
    }

    public void Registernew(View view){
        Intent intent = new Intent(this, Registernew.class);
        startActivity(intent);
    }

    private TextWatcher loginTextWatcher=new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String usernameInput = editTextUsername.getText().toString().trim();
            String passwordInput = editTextPassword.getText().toString().trim();
            buttonLogin.setEnabled(!usernameInput.isEmpty() && !passwordInput.isEmpty());

        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };

}

