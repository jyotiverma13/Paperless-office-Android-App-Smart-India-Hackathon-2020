package com.example.sihapplication;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class ListViewAdapter extends ArrayAdapter<String>
{
    private List<String> members = new ArrayList<>();
    private Context context;

    public ListViewAdapter(List<String> members,Context context)
    {
        super(context,R.layout.item_layout,members);
        this.context = context;
        this.members = members;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = ((Activity)context).getLayoutInflater();
        View row = inflater.inflate(R.layout.item_layout,parent,false);
        TextView membersName = row.findViewById(R.id.member);
        membersName.setText(members.get(position));
        return row;
    }

    public void removeItems(List<String> items)
    {
        for (String item : items)
        {
            members.remove(item);
        }
        notifyDataSetChanged();
    }

}
