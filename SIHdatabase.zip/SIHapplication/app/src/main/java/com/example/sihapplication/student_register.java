package com.example.sihapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;

import java.util.Arrays;

public class student_register extends AppCompatActivity {
    private static final String[] student_state_register = new String[]{
            "student_state1","studentstate2","student"
    };
    private static String[] category_list=new String[]{"General","OBC","SC/ST"};
    //public static final String[] student_dist_register = new String[]{
      //      "dstudent_state1","dstudentstate2"
    //};
    //public String[] string;
    //private int record;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_register);
        //Button button=(Button)findViewById(R.id.actvstatebtn);
        final AutoCompleteTextView editText = findViewById(R.id.actv_stu_state);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.stu_reg_state_list,android.R.layout.simple_list_item_1);
        editText.setAdapter(adapter);
        /*editText.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String selected = (String) adapterView.getItemAtPosition(i);
                int pos = Arrays.asList(student_state_register).indexOf(selected);
                if (pos == 0) {record = 1;}
                else if (pos == 1) {record = 2;}

            }
        });
        if (record == 1) {
            final AutoCompleteTextView eT = findViewById(R.id.actv_stu_dist);
            ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, student_dist_register);
            eT.setAdapter(adapter1);
        }*/
        final AutoCompleteTextView editText2 = findViewById(R.id.actv_student_category);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,category_list);
        editText2.setAdapter(adapter2);

    }

}
