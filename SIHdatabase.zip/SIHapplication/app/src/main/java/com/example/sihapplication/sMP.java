package com.example.sihapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class sMP extends AppCompatActivity {

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_m_p);

        listView = (ListView)findViewById(R.id.sMP);
        String[] values = new String[]{"Bhopal","Indore","Ujjain"};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_2,android.R.id.text1,values);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                  if (i==0){
                     Intent myIntent = new Intent(view.getContext(),dbhopal.class);
                     startActivityForResult(myIntent,0);
                  }

                else if (i==1){
                    Intent myIntent = new Intent(view.getContext(),dindore.class);
                    startActivityForResult(myIntent,0);
                }

            }
        });
    }
}
