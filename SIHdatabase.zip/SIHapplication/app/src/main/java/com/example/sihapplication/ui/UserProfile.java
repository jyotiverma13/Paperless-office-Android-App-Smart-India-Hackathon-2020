package com.example.sihapplication.ui;

public class UserProfile {
    public String userfullname,useremail,userpassword;

    public UserProfile(String FullName,String Email,String Password){
        this.userfullname = FullName;
        this.useremail = Email;
        this.userpassword = Password;
    }
}
