package com.example.sihapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class scholar_register extends AppCompatActivity {
     private static String[] commity_list=new String[]{"State","District"};
    private static String[] category_list=new String[]{"General","OBC","SC/ST"};
    private static String[] commity_type=new String[]{"State Welfare Commity","Out of State Welfare commity",};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scholar_register);
        final AutoCompleteTextView editText = findViewById(R.id.actv_sch_state2);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.stu_reg_state_list,android.R.layout.simple_list_item_1);
        editText.setAdapter(adapter);
        final AutoCompleteTextView editText1 = findViewById(R.id.actv_scholar_commity_level);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this,
                        android.R.layout.simple_list_item_1,commity_list);
        editText1.setAdapter(adapter1);
        final AutoCompleteTextView editText2 = findViewById(R.id.actv_scholar_category);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,category_list);
        editText2.setAdapter(adapter2);
        final AutoCompleteTextView editText3 = findViewById(R.id.actv_scholar_commity_type);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,commity_type);
        editText3.setAdapter(adapter3);
    }
}
