package com.example.sihapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MP_scholar_commity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m_p_scholar_commity);
    }
    public void Districts(View view){
        Intent intent = new Intent(this, sMP.class);
        startActivity(intent);
    }
}
