package com.example.sihapplication;

import android.app.Application;

public class SihApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

    }
}
