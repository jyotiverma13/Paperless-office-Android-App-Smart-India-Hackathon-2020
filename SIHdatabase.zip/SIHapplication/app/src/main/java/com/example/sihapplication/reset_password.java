package com.example.sihapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class reset_password extends AppCompatActivity {

    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        button=(Button)findViewById(R.id.button33);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //openDialogue();
                final AlertDialog.Builder alert=new AlertDialog.Builder(reset_password.this);
                View mView=getLayoutInflater().inflate(R.layout.send_recieve_enter_token,null);
                Button btn_cancle=(Button)mView.findViewById(R.id.button19);
                alert.setView(mView);
                final AlertDialog alertDialog=alert.create();
                alertDialog.setCanceledOnTouchOutside(true);
                btn_cancle.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                    alertDialog.dismiss();
                    }
                });
                Button btn_send=(Button)mView.findViewById(R.id.button17);
                btn_send.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });
                alertDialog.show();
            }
        });

    }

    /*private void openDialogue() {
     ExampleDialogue exampleDialogue=new ExampleDialogue();
     exampleDialogue.show(getSupportFragmentManager(),"example dialogue");
    }*/
}
