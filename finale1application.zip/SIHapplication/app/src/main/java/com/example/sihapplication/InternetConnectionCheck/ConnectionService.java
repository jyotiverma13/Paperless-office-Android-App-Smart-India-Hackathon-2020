package com.example.sihapplication.InternetConnectionCheck;


import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * Created by Abhishek on 21-09-2017.
 */

public class ConnectionService  extends Service {


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        IntentFilter intentFilter = new IntentFilter(ConnectivityChangeReceiver.NETWORK_AVAILABLE_ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                boolean isNetworkAvailable = intent.getBooleanExtra(ConnectivityChangeReceiver.IS_NETWORK_AVAILABLE, false);
                String networkStatus = isNetworkAvailable ? "connected" : "disconnected";

               if(networkStatus=="disconnected")
               {
//Intent i=new Intent(getApplicationContext(),NoInternetConnection.class);
  //                 i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    //               startActivity(i);

               }
               else{

               }

            }
        }, intentFilter);
        return super.onStartCommand(intent, flags, startId);
    }
}