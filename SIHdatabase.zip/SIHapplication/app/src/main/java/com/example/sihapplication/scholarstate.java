package com.example.sihapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class scholarstate extends AppCompatActivity {

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scholarstate);

        listView = (ListView)findViewById(R.id.sstates);
        String[] values = new String[]{"RAJ","UP","MP"};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_2,android.R.id.text1,values);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i==0){
                    Intent myIntent = new Intent(view.getContext(),raj_scholar_commity.class);
                    startActivityForResult(myIntent,0);
                }

                else if (i==1){
                    Intent myIntent = new Intent(view.getContext(),UP_scholar_commity.class);
                    startActivityForResult(myIntent,0);
                }

                else if (i==2){
                    Intent myIntent = new Intent(view.getContext(),MP_scholar_commity.class);
                    startActivityForResult(myIntent,0);
                }

            }
        });
    }
}
