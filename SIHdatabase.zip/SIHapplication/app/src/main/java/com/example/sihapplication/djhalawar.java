package com.example.sihapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.AbsListView;
import android.widget.ListView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class djhalawar extends AppCompatActivity {

    private ListView listView;
    private ListViewAdapter adapter;
    private List<String> members = new ArrayList<>();
    private List<String> UserSelection = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_djhalawar);
        getmembers();

        listView = findViewById(R.id.djListView);

        listView.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE_MODAL);
        listView.setMultiChoiceModeListener(modeListener);
        adapter = new ListViewAdapter(members,this);
        listView.setAdapter(adapter);
    }

    private void getmembers()
    {
        String[] items = getResources().getStringArray(R.array.members);

        for (String item : items)
        {
            members.add(item);
        }
    }

    AbsListView.MultiChoiceModeListener modeListener = new AbsListView.MultiChoiceModeListener() {

        @Override
        public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked)
        {
            if (UserSelection.contains(members.get(position)))
            {
                UserSelection.remove(members.get(position));
            }
            else
            {
                UserSelection.add(members.get(position));
            }

            mode.setTitle(UserSelection.size() +" items selected...");
        }

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater menuInflater = mode.getMenuInflater();
            menuInflater.inflate(R.menu.context_menu,menu);

            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {

            switch (item.getItemId())
            {
                case R.id.action_delete:
                    adapter.removeItems(UserSelection);
                    mode.finish();
                    return true;
                default:
                    return false;

                case R.id.action_share:
                    ApplicationInfo api = getApplicationContext().getApplicationInfo();
                    String apkpath = api.sourceDir;
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("application/vnd.android.package-archive");
                    intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File(apkpath)));
                    startActivity(Intent.createChooser(intent, "ShareVia"));
            }
            return true;


        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            UserSelection.clear();
        }
    };

}
