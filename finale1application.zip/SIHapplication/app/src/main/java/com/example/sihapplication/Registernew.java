package com.example.sihapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Registernew extends AppCompatActivity {
    EditText email;
    EditText password;
    EditText cnfpass;
    EditText full_name;
    private FirebaseAuth mAuth;
    ProgressBar progressBar;
    String email1,password1,cnfpass1,fullname;
    Spinner usertype;
    String[] usertype1 = {"Student","Administrator"};
    String usertype2;


// ...
// Initialize Firebase Auth

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registernew);
        email=(EditText)findViewById(R.id.email);
        password=(EditText)findViewById(R.id.password);
        cnfpass=(EditText)findViewById(R.id.confirm_password);
usertype=(Spinner)findViewById(R.id.usertype);
ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,usertype1);
usertype.setAdapter(arrayAdapter);
        progressBar=findViewById(R.id.progressBar);
        mAuth = FirebaseAuth.getInstance();
        usertype.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                usertype2=adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    public void opencontinue(View view){
      startposting();
    }

    public void startposting()
    {
         email1=email.getText().toString().trim();
        password1=password.getText().toString().trim();
         cnfpass1=cnfpass.getText().toString().trim();

        if (TextUtils.isEmpty(email1)){
            email.setError("Invalid Email");
            progressBar.setVisibility(View.GONE);
            return;
        }
        if (TextUtils.isEmpty(password1)){
            password.setError("Password is Required");
            progressBar.setVisibility(View.GONE);
            return;
        }
        if(password1.length()<8){
            password.setError("Password must be equals to 8 char. or more");
            progressBar.setVisibility(View.GONE);
        }
        if(password1.equals(cnfpass1)){
            //cnfpass.setError("Password Same");
        }else {
            cnfpass.setError("Password must be same");
            progressBar.setVisibility(View.GONE);
        }

        if(password1.equals(cnfpass1)){
            progressBar.setVisibility(View.VISIBLE);
            mAuth.createUserWithEmailAndPassword(email1, password1)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                //sendUserdata();
                                FirebaseUser user = mAuth.getCurrentUser();
                                String uid=user.getUid().toString();
                            if(usertype2=="Student"){
                                Intent i=new Intent(getApplicationContext(), CreateProfile_ST.class);
                                i.putExtra("userid",uid);
                                startActivity(i);
                             }
                            else {
                                Intent i1=new Intent(getApplicationContext(),admin_createprofile.class);
                                i1.putExtra("userid",uid);
                                startActivity(i1);
                            }
                                progressBar.setVisibility(View.GONE);
                                Toast.makeText(getApplicationContext(),"User Register Success",Toast.LENGTH_LONG).show();


                            } else {
                                // If sign in fails, display a message to the user.
                                Toast.makeText(getApplicationContext(),"User Register not Suceed",Toast.LENGTH_LONG).show();
                                progressBar.setVisibility(View.GONE);
                            }

                            // ...
                        }
                    });

        }
    }
    }
//    private void sendUserdata(){
//        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
//        DatabaseReference myRef = firebaseDatabase.getReference(mAuth.getUid());
//        UserProfile userProfile = new UserProfile(fullname,email1,password1);
//        myRef.setValue(userProfile);
//    }

