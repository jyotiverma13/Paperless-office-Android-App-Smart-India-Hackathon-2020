package com.example.sihapplication;

public class st_user_content {
    private String subject;
    private String status;
    private String message;
    private String item_Id;



    public st_user_content() {
    }

    public st_user_content(String subject, String status,String message, String item_Id) {
        this.subject = subject;
        this.status = status;
        this.message=message;
        this.item_Id=item_Id;    }
    public String getItem_Id() {
        return item_Id;
    }

    public void setItem_Id(String item_Id) {
        this.item_Id = item_Id;
    }
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
