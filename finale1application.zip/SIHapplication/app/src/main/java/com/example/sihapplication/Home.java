package com.example.sihapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.firebase.ui.firestore.SnapshotParser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.Transaction;
import com.williamww.silkysignature.views.SignaturePad;

import java.security.MessageDigest;
import java.util.HashMap;

import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;


public class Home extends AppCompatActivity  {

FloatingActionButton fab;
    private static final String fileName="usertype";
    String name;
    private FirebaseFirestore firebaseFirestore;

    String UID;
    Spinner reqSpinner;
    String [] status={"All Requests","Pending Requests","Approved Requests","Declined Requests"};
    CollectionReference db;
    FirebaseFirestore DB;

        @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home);

        readuser();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        DB = FirebaseFirestore.getInstance();
        UID=user.getUid();
        Toast.makeText(getApplicationContext(),UID,Toast.LENGTH_SHORT).show();
        db= FirebaseFirestore.getInstance().collection("communication");
        //spinner
        reqSpinner=findViewById(R.id.statusSpinner);
        ArrayAdapter<String> arrayAdapter1=new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,status);
        reqSpinner.setAdapter(arrayAdapter1);


    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.navactivity,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.profile){
            if(name.equals("Students")){
                Intent intent = new Intent (this, st_manage_profile.class);
                startActivity(intent);
            }if(name.equals("Admin")){
                Intent intent = new Intent(this, admin_manage_profile.class);
                startActivity(intent);
            }
        }
        if(item.getItemId()==R.id.action_logout)
        {
            FirebaseAuth.getInstance().signOut();
            Intent i=new Intent(getApplicationContext(),LoginActivity.class);
            startActivity(i);
//            SharedPreferences sharedPreferences = getSharedPreferences("fileName", Context.MODE_PRIVATE);
//            SharedPreferences.Editor editor=sharedPreferences.edit();
//            editor.clear();
//            editor.commit();
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void readuser(){

        SharedPreferences sharedPreferences=getSharedPreferences(fileName, Context.MODE_PRIVATE);
        String defaultvalue="null";
        name=sharedPreferences.getString("usertype",defaultvalue);
        Toast.makeText(getApplicationContext(),name,Toast.LENGTH_LONG).show();
        firebaseFirestore = FirebaseFirestore.getInstance();

    }


}