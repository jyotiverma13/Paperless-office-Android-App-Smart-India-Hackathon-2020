package com.example.sihapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class LoginActivity extends AppCompatActivity {
    private static final String[] departments = new String[]{
            "Student","Scholarship","Tequip","Sports","WHO","Others"
    };
    private EditText editTextUsername;
    private EditText editTextPassword;
    TextView forgot_password;
    Button buttonLogin;
    FirebaseAuth mAuth;
    ProgressBar progressBar;
    Spinner user_selector;
    String[] ofuserselector={"Students","Admin"};
    String selecteduser;
    private static final String fileName="usertype";
    String user;
    CollectionReference db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       /* AutoCompleteTextView editText=findViewById(R.id.actv1);
        ArrayAdapter<String>adapter=new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,departments);
        editText.setAdapter(adapter);*/
        user_selector=(Spinner)findViewById(R.id.loginuser);
        ArrayAdapter<String> arrayAdapter1=new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,ofuserselector);
        user_selector.setAdapter(arrayAdapter1);
        user_selector.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selecteduser=adapterView.getItemAtPosition(i).toString();
                //Toast.makeText(getApplicationContext(),selecteduser,Toast.LENGTH_SHORT).show();

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        editTextUsername=findViewById(R.id.eTemail);
        editTextPassword=findViewById(R.id.etPassword);
        buttonLogin=findViewById(R.id.button1);
        progressBar=findViewById((R.id.login_progressBar));
        mAuth=FirebaseAuth.getInstance();
        editTextUsername.addTextChangedListener(loginTextWatcher);
        editTextPassword.addTextChangedListener(loginTextWatcher);
        forgot_password=(TextView)findViewById(R.id.forgetPassword);
        forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText resetmail=new EditText((view.getContext()));
                AlertDialog.Builder pswdreset_dialog= new AlertDialog.Builder(view.getContext());
                pswdreset_dialog.setTitle("Reset Password");
                pswdreset_dialog.setMessage("Enter Registered Email To Recieve Password Reset Link");
                pswdreset_dialog.setView(resetmail);
                pswdreset_dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //extract the email and send link
                        String mail = resetmail.getText().toString().trim();
                        mAuth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(getApplicationContext(),"Link Sent",Toast.LENGTH_LONG).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(),"Error! Link Not Sent"+e.getMessage(),Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                });
                pswdreset_dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //close dialoge
                    }
                });
                pswdreset_dialog.create().show();

            }
        });
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
              //checkuser();
            }
        });
    }

    public void Registernew(View view){
        Intent intent = new Intent(this, Registernew.class);
        startActivity(intent);
    }

    private TextWatcher loginTextWatcher=new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String usernameInput = editTextUsername.getText().toString().trim();
            String passwordInput = editTextPassword.getText().toString().trim();
            buttonLogin.setEnabled(!usernameInput.isEmpty() && !passwordInput.isEmpty());

        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };
    private void saveuser(){
        user=selecteduser;
//        selecteduser="Students";
        SharedPreferences sharedPreferences=getSharedPreferences(fileName, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString("usertype",user);
        editor.commit();
        Toast.makeText(getApplicationContext(),user,Toast.LENGTH_SHORT).show();
    }
    public void checkuser(){
        db= FirebaseFirestore.getInstance().collection(selecteduser);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        db.document(user.getUid().toString()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
           if(task.isSuccessful()){
               if(task.getResult().exists()){
                   startActivity(new Intent(getApplicationContext(),Home.class));
                   finish();
               }else {
                   Toast.makeText(getApplicationContext(),"Something went wrong !! Try again using correct user",Toast.LENGTH_SHORT).show();
                   progressBar.setVisibility((View.GONE));
               }
           }   else{

           }
            }
        });
    }
    public void login() {
        saveuser();
        String usernameInput = editTextUsername.getText().toString().trim();
        String passwordInput = editTextPassword.getText().toString().trim();
        if (TextUtils.isEmpty(usernameInput)){
            editTextUsername.setError("Invalid Email");
            progressBar.setVisibility((View.GONE));
            return;
        }
        if (TextUtils.isEmpty(passwordInput)){
            editTextPassword.setError("Password is Required");
            progressBar.setVisibility((View.GONE));
            return;
        }
        //String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if(passwordInput.length()<8){
            editTextPassword.setError("Password must be equals to 8 char. or more");
            progressBar.setVisibility((View.GONE));
        }
        progressBar.setVisibility(View.VISIBLE);
        mAuth.signInWithEmailAndPassword(usernameInput,passwordInput)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            //Toast.makeText(getApplicationContext(),user.getEmail().toString(),Toast.LENGTH_LONG).show();
                            //startActivity(new Intent(getApplicationContext(),navactivity.class));
                            checkuser();
                        }

                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(),"User login failed",Toast.LENGTH_LONG).show();
                progressBar.setVisibility((View.GONE));
            }
        });
    }



}

