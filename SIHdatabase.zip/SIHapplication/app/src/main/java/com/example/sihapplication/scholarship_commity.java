package com.example.sihapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class scholarship_commity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scholarship_commity);
    }

    public void sstate(View view) {
        Intent intent = new Intent(this, scholarstate.class);
        startActivity(intent);
    }

    public void scnationall(View view) {
        Intent intent = new Intent(this, snational.class);
        startActivity(intent);
    }

    public void go_to_department(View view) {
        Intent intent = new Intent(this, navactivity.class);
        startActivity(intent);

    }
}
