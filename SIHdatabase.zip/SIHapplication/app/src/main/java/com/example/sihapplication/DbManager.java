package com.example.sihapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbManager extends SQLiteOpenHelper {

    public static final String  dbname="Paperless.db";

    public DbManager( Context context) {
        super(context,dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String qry="create table login_sys (id integer primary key autoincrement, email text,password text)";
        db.execSQL(qry);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS login_sys");
        onCreate(db);
    }
    public String Login(String p1,String p2)
    {
        SQLiteDatabase db =this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("email",p1);
        cv.put("password",p2);

        long res = db.insert("login_sys",null,cv);
        if(res==-1)
            return "Failed";
        else
            return "Successfully Login";
    }
}
